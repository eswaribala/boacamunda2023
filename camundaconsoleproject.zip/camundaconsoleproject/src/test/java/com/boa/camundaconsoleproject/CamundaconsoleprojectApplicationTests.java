package com.boa.camundaconsoleproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamundaconsoleprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
