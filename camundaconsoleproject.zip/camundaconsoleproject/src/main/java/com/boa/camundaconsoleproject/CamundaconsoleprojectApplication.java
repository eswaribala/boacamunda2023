package com.boa.camundaconsoleproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamundaconsoleprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamundaconsoleprojectApplication.class, args);
	}

}
